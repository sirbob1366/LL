public class LinkedListMethods {
    private Node start;
    public void LLcreator(int a){
        info=a;
        link=null;//points to null to initate

        Node temp=new Node(a);//creates new node with data a
        start=temp;// start node data  to node temp data
        temp.link=start;//links temp to start data

        if (start==null){//checks if start is null
            start=temp;//if it is then start is now temp
        }
    }
    public void insertInBeginning(int data)
    {
        Node temp=new Node(data);
        temp.link=start;
        start=temp;
    }
    public void insertAtEnd(int data)
    {
        Node p;
        Node temp=new Node(data);
        if(start==null)
        {
            start=temp;
            return;
        }
        p=start;
        while(p.link!=null)
            p=p.link;
        p.link=temp;
    }

    public void insertNodeGivenDataAfter(int data, int given){
        Node p=start;//initalizing node p as start
        while (p.link!=null){//loop of what p links to until the pointer goes to null (last node)
           if(p.info==given){// if p matches given then stop
               break;
               p=p.link//p is where the pointer stopped at
           }
        }
        Node temp= new Node(data);//create new node
        temp.link=p.link;//links temp is now p link
        p.link=temp;//p links to temp data
    }
    public void insertNodeGivenDataBefore(int data, int given){
        Node p=start;//initalizing node p as start
        while(p.link!=null){//loop of what p links to until the pointer goes to null (last node)
            if(p.link.info==given){//if what p links data matches what is given stop the pointer
                break;
                p=p.link//p is where the pointer is at
            }
        }
        Node temp=new Node(data);
        temp.link=p.link;
        p.link=temp;
    }
    public void insertNodeAtAGvenPosition(int data, int position){
        Node p=start;
        for(int i=0; i<positon && p.link!=null; i++)
        {
            p=p.link;
        }
        Node temp= new Node(data);
        temp.link=p.link;
        p.link=temp;
    }
    public void reverseLL(){
        Node prev,p,next;// declaring some nodes
        while(p.link!=null){//loop of what p links to until the pointer goes to null (last node)
            next=p.link;
            p.link=prev;
            prev=p;
            p=next;
        }
        start=prev;
    }
    public void deleteNodeGivenData(int data){
        Node p=start;//initalizing node p as start
        while(p.link!=null)//loop of what p links to until the pointer goes to null (last node)
        {
            if (p.link.info==data){
                break;
                p=p.link;
            }
        }
        p=p.link.link;
    }

}
